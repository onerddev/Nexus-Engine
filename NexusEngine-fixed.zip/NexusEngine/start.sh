#!/bin/bash
# ================================================================
# NexusEngine — Script de inicialização
# Autor: Emanuel Felipe
# ================================================================
set -e

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

echo -e "${CYAN}"
echo "  ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗"
echo "  ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝"
echo "  ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗"
echo "  ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║"
echo "  ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║"
echo "  ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝"
echo -e "${NC}"
echo -e "${GREEN}  NexusEngine Omega v1.0.0 — por Emanuel Felipe${NC}"
echo ""

# Verifica Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[ERRO] Python 3 não encontrado. Instale Python 3.10+${NC}"
    exit 1
fi

PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo -e "${YELLOW}[INFO] Python $PY_VER detectado${NC}"

# Instala dependências se necessário
if ! python3 -c "import fastapi" &> /dev/null 2>&1; then
    echo -e "${YELLOW}[INFO] Instalando dependências...${NC}"
    pip3 install fastapi uvicorn[standard] pydantic pydantic-settings python-dotenv --quiet
    echo -e "${GREEN}[OK] Dependências instaladas${NC}"
fi

# Porta e host
HOST=${API_HOST:-0.0.0.0}
PORT=${API_PORT:-8000}

echo -e "${GREEN}[OK] Iniciando servidor em http://${HOST}:${PORT}${NC}"
echo -e "${CYAN}[INFO] Docs disponíveis em: http://localhost:${PORT}/docs${NC}"
echo ""

# Roda a API
python3 -m uvicorn api.main:app --host $HOST --port $PORT --reload
