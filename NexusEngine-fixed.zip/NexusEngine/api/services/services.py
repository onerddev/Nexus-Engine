"""
Core services for NexusEngine API
Fixed: Python-native implementations when Cython unavailable
       Binary operations, matrix, quantum simulation all work without C++
"""

import logging
import math
import random
import struct
from typing import Optional, List, Dict
from datetime import datetime

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Python-native fallback engines (used when Cython/C++ not compiled)
# ──────────────────────────────────────────────────────────────────────────────

class _BinaryProcessorPy:
    """Pure-Python binary processor"""
    def xor(self, a: int, b: int) -> int:  return a ^ b
    def and_(self, a: int, b: int) -> int: return a & b
    def or_(self, a: int, b: int) -> int:  return a | b
    def not_(self, a: int) -> int:
        # 64-bit NOT
        return a ^ 0xFFFFFFFFFFFFFFFF
    def to_binary(self, v: int) -> str:    return bin(v)
    def count_bits(self, v: int) -> int:   return bin(v).count('1')


class _MatrixEnginePy:
    """Pure-Python matrix engine"""
    def zeros(self, rows: int, cols: int) -> List[List[float]]:
        return [[0.0] * cols for _ in range(rows)]
    def ones(self, rows: int, cols: int) -> List[List[float]]:
        return [[1.0] * cols for _ in range(rows)]
    def identity(self, n: int) -> List[List[float]]:
        m = [[0.0] * n for _ in range(n)]
        for i in range(n): m[i][i] = 1.0
        return m
    def random(self, rows: int, cols: int) -> List[List[float]]:
        return [[random.gauss(0, 1) for _ in range(cols)] for _ in range(rows)]
    def create(self, rows: int, cols: int) -> List[List[float]]:
        return self.zeros(rows, cols)


class _QuantumSimulatorPy:
    """
    Pure-Python quantum state simulator (statevector).
    State vector has 2^n complex amplitudes for n qubits.
    """
    def __init__(self, n_qubits: int):
        self.n = n_qubits
        self.dim = 1 << n_qubits          # 2^n
        # |0...0⟩ ground state
        self.state = [complex(0) for _ in range(self.dim)]
        self.state[0] = complex(1)

    def initialize_ground(self):
        self.state = [complex(0)] * self.dim
        self.state[0] = complex(1)

    def initialize_superposition(self):
        amp = 1.0 / math.sqrt(self.dim)
        self.state = [complex(amp) for _ in range(self.dim)]

    def initialize_random(self):
        raw = [complex(random.gauss(0,1), random.gauss(0,1)) for _ in range(self.dim)]
        norm = math.sqrt(sum(abs(a)**2 for a in raw))
        self.state = [a/norm for a in raw]

    def probability_zero(self, qubit: int) -> float:
        """P(qubit=0) = sum |a_i|^2 for all i where bit qubit == 0"""
        prob = 0.0
        for i in range(self.dim):
            if not (i >> qubit & 1):
                prob += abs(self.state[i])**2
        return prob

    def probability_one(self, qubit: int) -> float:
        return 1.0 - self.probability_zero(qubit)


# ──────────────────────────────────────────────────────────────────────────────
# Service classes
# ──────────────────────────────────────────────────────────────────────────────

class EngineService:
    """Engine lifecycle management"""

    def __init__(self):
        self.engine     = None
        self.is_running = False

    def start(self, threads: int = 4):
        try:
            try:
                import nexus_engine
                self.engine = nexus_engine.PyCoreEngine()
                self.engine.start()
                logger.info("Cython/C++ engine loaded")
            except ImportError:
                logger.warning("Cython bindings not available — running in Python mode")
                self.engine = None

            self.is_running = True
            logger.info(f"Engine started with {threads} threads")
            return True
        except Exception as e:
            logger.error(f"Failed to start engine: {e}")
            return False

    def stop(self):
        try:
            if self.engine:
                self.engine.stop()
            self.is_running = False
            logger.info("Engine stopped")
            return True
        except Exception as e:
            logger.error(f"Failed to stop engine: {e}")
            return False

    def get_status(self) -> dict:
        return {
            "running":   self.is_running,
            "timestamp": datetime.utcnow().isoformat()
        }


class ComputeService:
    """Computation services — works with or without Cython"""

    def __init__(self):
        # Try Cython first, fall back to Python
        try:
            import nexus_engine
            self.bp           = nexus_engine.PyBinaryProcessor()
            self.matrix       = nexus_engine.PyMatrixEngine()
            self.hash_engine  = nexus_engine.PyHashEngine()
            self._use_cython  = True
            logger.info("Using Cython compute engines")
        except ImportError:
            self.bp           = _BinaryProcessorPy()
            self.matrix       = _MatrixEnginePy()
            self.hash_engine  = None
            self._use_cython  = False
            logger.warning("Using Python compute engines (Cython not compiled)")

    # ── Binary ──────────────────────────────────────────────────────────────

    def binary_operation(self, operation: str, value_a: int, value_b: Optional[int] = None) -> dict:
        try:
            b = value_b or 0
            if   operation == "xor": result = self.bp.xor(value_a, b)
            elif operation == "and": result = self.bp.and_(value_a, b)
            elif operation == "or":  result = self.bp.or_(value_a, b)
            elif operation == "not": result = self.bp.not_(value_a)
            else: return {"error": f"Unknown operation: {operation}"}

            return {
                "result":        result,
                "result_binary": self.bp.to_binary(result) if hasattr(self.bp, 'to_binary') else bin(result)
            }
        except Exception as e:
            logger.error(f"Binary operation failed: {e}")
            return {"error": str(e)}

    # ── Matrix ───────────────────────────────────────────────────────────────

    def matrix_compute(self, operation: str, rows: int, cols: int) -> dict:
        try:
            if   operation == "zeros":    mat = self.matrix.zeros(rows, cols)
            elif operation == "ones":     mat = self.matrix.ones(rows, cols)
            elif operation == "identity": mat = self.matrix.identity(rows)
            elif operation == "random":   mat = self.matrix.random(rows, cols)
            elif operation == "create":   mat = self.matrix.create(rows, cols)
            else: return {"error": f"Unknown operation: {operation}"}

            sr, sc = min(3, len(mat)), min(3, len(mat[0]) if mat else 0)
            sample = [[round(mat[i][j], 6) for j in range(sc)] for i in range(sr)]
            return {"operation": operation, "rows": rows, "cols": cols, "sample": sample}
        except Exception as e:
            logger.error(f"Matrix computation failed: {e}")
            return {"error": str(e)}

    # ── Quantum ───────────────────────────────────────────────────────────────

    def quantum_simulate(self, qubits: int, operation: str,
                         qubit_index: Optional[int] = None) -> dict:
        try:
            if self._use_cython:
                import nexus_engine
                qsim = nexus_engine.PyQuantumSimulator(qubits)
            else:
                qsim = _QuantumSimulatorPy(qubits)

            if   operation == "ground":       qsim.initialize_ground()
            elif operation == "superposition": qsim.initialize_superposition()
            elif operation == "random":        qsim.initialize_random()
            else:                              qsim.initialize_ground()   # default

            probs = []
            for i in range(min(qubits, 8)):
                p0 = qsim.probability_zero(i)
                p1 = qsim.probability_one(i)
                probs.append({"qubit": i, "p0": round(p0, 6), "p1": round(p1, 6)})

            return {"probabilities": probs}
        except Exception as e:
            logger.error(f"Quantum simulation failed: {e}")
            return {"error": str(e)}


class MetricsService:
    """Metrics collection and reporting"""

    def __init__(self):
        self.start_time       = datetime.utcnow()
        self.total_operations = 0
        self.total_errors     = 0
        self.latencies: List[float] = []

    def record_operation(self, latency_us: float, success: bool = True):
        self.total_operations += 1
        if not success:
            self.total_errors += 1
        self.latencies.append(latency_us)

    def get_aggregated_metrics(self) -> dict:
        if not self.latencies:
            return {
                "total_operations": 0, "total_errors": 0, "error_rate": 0.0,
                "latency_us": {"p50":0,"p95":0,"p99":0,"p999":0,"mean":0,"min":0,"max":0},
                "throughput_ops_sec": 0.0, "queue_size": 0,
                "cpu_usage_percent": 0.0, "memory_bytes": 0, "uptime_seconds": 0
            }

        sl     = sorted(self.latencies)
        n      = len(sl)
        uptime = max(1, (datetime.utcnow() - self.start_time).total_seconds())

        def pct(p): return sl[min(int(n * p), n-1)]

        return {
            "total_operations":   self.total_operations,
            "total_errors":       self.total_errors,
            "error_rate":         self.total_errors / self.total_operations,
            "latency_us": {
                "p50":  pct(.50), "p95": pct(.95),
                "p99":  pct(.99), "p999": sl[-1],
                "mean": sum(self.latencies) / n,
                "min":  sl[0],    "max": sl[-1]
            },
            "throughput_ops_sec": self.total_operations / uptime,
            "queue_size":         0,
            "cpu_usage_percent":  0.0,
            "memory_bytes":       0,
            "uptime_seconds":     int(uptime)
        }


# Global singleton instances
engine_service  = EngineService()
compute_service = ComputeService()
metrics_service = MetricsService()
