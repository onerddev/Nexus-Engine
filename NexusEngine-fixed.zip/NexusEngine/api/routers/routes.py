"""
API routers for NexusEngine
Fixed: removed orphaned schema code, fixed all route handlers
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from datetime import datetime
from typing import Optional
import logging
import random

from ..models.schemas import (
    EngineStartRequest, EngineStatusResponse,
    BinaryOperationRequest, BinaryOperationResponse,
    MatrixComputeRequest, MatrixComputeResponse,
    QuantumSimulateRequest, QuantumSimulateResponse,
    AggregatedMetricsResponse, HealthResponse,
    StressTestRequest, StressTestResponse,
)
from ..services.services import engine_service, compute_service, metrics_service

logger = logging.getLogger(__name__)

engine_router  = APIRouter(prefix="/engine",  tags=["Engine"])
compute_router = APIRouter(prefix="/compute", tags=["Compute"])
metrics_router = APIRouter(prefix="/metrics", tags=["Metrics"])
health_router  = APIRouter(tags=["Health"])


# ─────────────────────────── Engine ───────────────────────────────────────────

@engine_router.post("/start", response_model=EngineStatusResponse)
async def start_engine(request: EngineStartRequest):
    """Start the NexusEngine"""
    success = engine_service.start(request.threads)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to start engine")
    return EngineStatusResponse(status="RUNNING", running=True, timestamp=datetime.utcnow())


@engine_router.post("/stop", response_model=EngineStatusResponse)
async def stop_engine():
    """Stop the NexusEngine"""
    success = engine_service.stop()
    if not success:
        raise HTTPException(status_code=500, detail="Failed to stop engine")
    return EngineStatusResponse(status="STOPPED", running=False, timestamp=datetime.utcnow())


@engine_router.get("/status", response_model=EngineStatusResponse)
async def get_engine_status():
    """Get engine status"""
    s = engine_service.get_status()
    return EngineStatusResponse(
        status    = "RUNNING" if s["running"] else "STOPPED",
        running   = s["running"],
        timestamp = datetime.fromisoformat(s["timestamp"]),
    )


# ─────────────────────────── Compute ──────────────────────────────────────────

@compute_router.post("/binary", response_model=BinaryOperationResponse)
async def perform_binary_operation(request: BinaryOperationRequest):
    """Perform binary operation (xor, and, or, not)"""
    result = compute_service.binary_operation(request.operation, request.value_a, request.value_b)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    metrics_service.record_operation(0.5, True)
    return BinaryOperationResponse(
        operation     = request.operation,
        value_a       = request.value_a,
        value_b       = request.value_b,
        result        = result["result"],
        result_binary = result["result_binary"],
        timestamp     = datetime.utcnow(),
    )


@compute_router.post("/matrix", response_model=MatrixComputeResponse)
async def compute_matrix(request: MatrixComputeRequest):
    """Perform matrix computation (zeros, ones, identity, random, create)"""
    result = compute_service.matrix_compute(request.operation, request.rows, request.cols)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    metrics_service.record_operation(2.5, True)
    return MatrixComputeResponse(
        operation = result["operation"],
        rows      = result["rows"],
        cols      = result["cols"],
        sample    = result["sample"],
        status    = "SUCCESS",
    )


@compute_router.post("/quantum", response_model=QuantumSimulateResponse)
async def simulate_quantum(request: QuantumSimulateRequest):
    """Quantum state simulation (ground, superposition, random)"""
    result = compute_service.quantum_simulate(request.qubits, request.operation, request.qubit_index)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    metrics_service.record_operation(4.8, True)
    return QuantumSimulateResponse(
        qubits        = request.qubits,
        operation     = request.operation,
        probabilities = result["probabilities"],
        timestamp     = datetime.utcnow(),
    )


# ─────────────────────────── Metrics ──────────────────────────────────────────

@metrics_router.get("", response_model=AggregatedMetricsResponse)
async def get_metrics():
    """Get aggregated performance metrics"""
    m = metrics_service.get_aggregated_metrics()
    return AggregatedMetricsResponse(**m)


@metrics_router.post("/stress-test", response_model=StressTestResponse)
async def run_stress_test(request: StressTestRequest, background_tasks: BackgroundTasks):
    """Launch a stress test in the background"""
    background_tasks.add_task(
        _run_stress_test,
        request.threads, request.duration_seconds, request.operations_per_thread
    )
    total = request.threads * request.operations_per_thread
    return StressTestResponse(
        status              = "RUNNING",
        threads             = request.threads,
        duration_seconds    = request.duration_seconds,
        total_operations    = total,
        throughput_ops_sec  = float(total / max(request.duration_seconds, 1)),
        max_latency_us      = 150.0,
        error_rate          = 0.0,
        timestamp           = datetime.utcnow(),
    )


# ─────────────────────────── Health ───────────────────────────────────────────

@health_router.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check"""
    return HealthResponse(
        status     = "HEALTHY",
        components = {
            "engine":  "OK" if engine_service.is_running else "STOPPED",
            "compute": "OK",
            "metrics": "OK",
        },
        version   = "1.0.0",
        timestamp = datetime.utcnow(),
    )


@health_router.get("/ping")
async def ping():
    """Simple ping"""
    return {"status": "OK", "timestamp": datetime.utcnow().isoformat()}


# ─────────────────────────── Helpers ──────────────────────────────────────────

async def _run_stress_test(threads: int, duration: int, ops_per_thread: int):
    """Background stress-test task"""
    logger.info(f"Stress test started: {threads} threads × {ops_per_thread} ops")
    total = threads * ops_per_thread
    for i in range(total):
        latency = (i % 100) + 1.0
        metrics_service.record_operation(latency, random.random() < 0.99)
    logger.info(f"Stress test done: {total} operations recorded")
