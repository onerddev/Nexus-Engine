"""
NexusEngine API — Main Application
Autor: Emanuel Felipe
"""

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging
import os
from dotenv import load_dotenv

from api.routers.routes import engine_router, compute_router, metrics_router, health_router
from api.middleware.middleware import (
    RequestIDMiddleware, LoggingMiddleware, RateLimitMiddleware, CORSMiddleware
)
from api.services.services import engine_service

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("NexusEngine API starting…")
    yield
    logger.info("NexusEngine API shutting down…")
    engine_service.stop()


app = FastAPI(
    title       = "NexusEngine Omega API",
    description = "Ultra Low Latency Hybrid Computational Engine — by Emanuel Felipe",
    version     = "1.0.0",
    lifespan    = lifespan,
)

app.add_middleware(CORSMiddleware)
app.add_middleware(RateLimitMiddleware, requests_per_second=1000)
app.add_middleware(LoggingMiddleware)
app.add_middleware(RequestIDMiddleware)

app.include_router(engine_router)
app.include_router(compute_router)
app.include_router(metrics_router)
app.include_router(health_router)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "detail": str(exc), "path": str(request.url.path)}
    )


@app.get("/")
async def root():
    return {
        "name":       "NexusEngine Omega",
        "version":    "1.0.0",
        "author":     "Emanuel Felipe",
        "status":     "online",
        "docs_url":   "/docs",
        "api_version": "v1"
    }


@app.get("/ready")
async def ready():
    return {"status": "ready"}


if __name__ == "__main__":
    import uvicorn
    host    = os.getenv("API_HOST", "0.0.0.0")
    port    = int(os.getenv("API_PORT", "8000"))
    reload  = os.getenv("API_RELOAD", "false").lower() == "true"
    uvicorn.run("api.main:app", host=host, port=port, reload=reload)
